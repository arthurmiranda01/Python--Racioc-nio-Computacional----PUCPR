while True:
    # Mostrando o menu principal do sistema.

    print("Bem-Vindo ao Menu do Sistema PUC")
    print("1. Estudantes")
    print("2. Professores")
    print("3. Disciplinas")
    print("4. Turmas")
    print("5. Matrículas")
    print("0. Sair")

    #Variáveis das respostas do primeiro menu
    student_option = ("Estudantes")
    professor_option = ("Professores")
    subject_option = ("Disciplinas")
    class_option = ("Turmas")
    enrollment_option = ("Matrículas")
    exit_option = ("Sair")

    #Coletando a resposta do usuário
    option = int(input("Digite uma opção válida"))

    if option == 1 or option == 2 or option == 3 or option == 4 or option == 5:
        print(f"Você escolheu a opção válida: {option}")

        #Mostrando o menu de operações da opção escolhida
        while True:
            if option == 1:
                print(f"Menu de Operações - Opção: {student_option}")
                print("1. Criar")
                print("2. Listar")
                print("3. Atualizar")
                print("4. Excluir")
                print("0. Voltar")
            
            elif option == 2:
                print(f"Menu de Operações - Opção: {professor_option}")
                print("1. Criar")
                print("2. Listar")
                print("3. Atualizar")
                print("4. Excluir")
                print("0. Voltar")
            elif option == 3:
                print(f"Menu de Operações - Opção: {subject_option}")
                print("1. Criar")
                print("2. Listar")
                print("3. Atualizar")
                print("4. Excluir")
                print("0. Voltar")
            elif option == 4:
                print(f"Menu de Operações - Opção: {class_option}")
                print("1. Criar")
                print("2. Listar")
                print("3. Atualizar")
                print("4. Excluir")
                print("0. Voltar")
            elif option == 5:
                print(f"Menu de Operações - Opção: {enrollment_option}")
                print("1. Criar")
                print("2. Listar")
                print("3. Atualizar")
                print("4. Excluir")
                print("0. Voltar")

            #Coletando a resposta do segundo menu
            second_option = int(input("Digite uma opção válida"))

            #Variáveis das respostas do segundo menu
            create_option = ("Criar")
            list_option = ("Listar")
            att_option = ("Atualizar")
            excl_option = ("Excluir")

            if second_option == 1:
                print(f"Você escolheu a opção válida: {second_option} - {create_option}")
            elif second_option == 2:
                print(f"Você escolheu a opção válida: {second_option} - {list_option}")
            elif second_option == 3:
                print(f"Você escolheu a opção válida: {second_option} - {att_option}")
            elif second_option == 4:
                print(f"Você escolheu a opção válida: {second_option} - {excl_option}")
            elif second_option == 0:
                print("Você pediu para voltar.")  
                break
            else: 
                print(f"Você escolheu uma alternativa incorreta: {second_option}")

    elif option == 0:
            print("Você pediu para sair.")
            break

    else:
        print(f"Você escolheu uma alternativa incorreta: {option}")     

