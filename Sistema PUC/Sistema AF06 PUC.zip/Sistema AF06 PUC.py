import json

#Criando as funções para utilização no código
#Função Menu Principal
def display_mainMenu():
    print("Bem-Vindo ao Menu do Sistema PUC")
    print("1. Estudantes")
    print("2. Professores")
    print("3. Disciplinas")
    print("4. Turmas")
    print("5. Matrículas")
    print("0. Sair")
    return int(input("Digite uma opção válida"))

#Função Menu Secundário
def display_secondMenu():
    print("1. Criar")
    print("2. Listar")
    print("3. Atualizar")
    print("4. Excluir")
    print("0. Voltar")

#Função Criar Estudante
def creating_Student(students):
    studentName = input("Insira o nome do aluno.")
    studentCode = int(input("Insira o Código do Estudante."))
    studentDocument = input("Insira o CPF do Estudante.")
    student_data = {
                    'Nome': studentName,
                    'Código do Estudante': studentCode,
                    'CPF': studentDocument
                }
    students.append(student_data)
    save_archive(students, "studentsList.json")
    return students

#Função Editar Estudante
def editing_Student():
    students = read_archive("studentsList.json")
    edit_student = int(input('Digite o código do aluno que você deseja editar: '))
    editable_student = None
    for student_data in students:
        if student_data['Código do Estudante'] == edit_student:
            editable_student = student_data
            
        if editable_student == None:
                    print(f'Não encontramos estudantes com o código {edit_student} no sistema.')
        else:
                    editable_student['Nome'] = input('Digite o novo nome do Estudante: ')
                    editable_student['Código do Estudante'] = input('Digite o novo Código do Estudante: ')
                    editable_student['CPF'] = input('Digite o novo CPF do Estudante: ')
                    
    print(f'O estudante {editable_student} foi editado com sucesso.')
    save_archive(students, "studentsList.json")

#Função Listar Estudante
def listing_Student(students):
    students = read_archive("studentsList.json")
    if len(students) == 0:
        print("A lista atualmente está vazia")
    else:
        for student_name in students:
            print(f'- {student_name}')
    return students

#Função Excluir Estudante
def excluding_Student(students):
    students = read_archive("studentsList.json")
    exclude_student = int(input('Digite o código do aluno que você deseja excluir: '))
    removeble_student = None
    for student_data in students:
        if student_data['Código do Estudante'] == exclude_student:
            removeble_student = student_data
        breakpoint
        if removeble_student == None:
                    print(f'Não encontramos estudantes com o código {exclude_student} no sistema.')
        else:
                    students.remove(removeble_student)
                    print(f'O estudante {removeble_student} foi removido com sucesso.')
                    save_archive(students, "studentsList.json")
                    
#Função Criar Arquivo de Armazenamento
def save_archive(students, studentsList):
     with open(studentsList, 'w', encoding='utf-8') as file_opened:
          json.dump(students, file_opened, ensure_ascii=False)

#Função para ler o arquivo de armazenamento
def read_archive(studentsList):
    try:
        with open(studentsList, 'r', encoding='utf-8') as file_opened:
            students = json.load(file_opened)
            return students
    except Exception as e:
         print(f"Exceção ocorrida: {e}")
         return[]
          
#Criando a lista para armazenar os nomes dos estudantes
students = []

#Variáveis das respostas do primeiro menu
student_option = ("Estudantes")
professor_option = ("Professores")
subject_option = ("Disciplinas")
class_option = ("Turmas")
enrollment_option = ("Matrículas")
exit_option = ("Sair")

#Variáveis das respostas do segundo menu
create_option = ("Criar")
list_option = ("Listar")
att_option = ("Atualizar")
excl_option = ("Excluir")

while True:
    # Mostrando o menu principal do sistema.
    option = display_mainMenu()

    if option == 1:
        print(f"Você escolheu a opção válida: {option}")

        #Mostrando o menu de operações da opção escolhida
        while True:
            if option == 1:
                print(f"Menu de Operações - Opção: {student_option}")
                display_secondMenu()
            
            elif option == 2:
                print(f"Menu de Operações - Opção: {professor_option}")
                display_secondMenu()

            elif option == 3:
                print(f"Menu de Operações - Opção: {subject_option}")
                display_secondMenu()
                
            elif option == 4:
                print(f"Menu de Operações - Opção: {class_option}")
                display_secondMenu()
                
            elif option == 5:
                print(f"Menu de Operações - Opção: {enrollment_option}")
                display_secondMenu()
                

            #Coletando a resposta do segundo menu
            second_option = int(input("Digite uma opção válida"))

            if second_option == 1:
                print(f"Você escolheu a opção válida: {second_option} - {create_option}")
                creating_Student(students)
                print(f"Você adicionou corretamente o aluno {students[-1]['Nome']} para a lista")

            elif second_option == 2:
                print(f"Você escolheu a opção válida: {second_option} - {list_option}")
                #Listando os alunos, caso a lista esteja vazia, o sistema informará.
                listing_Student(students)
            
            #Editando o estudante
            elif second_option == 3:
                print(f"Você escolheu a opção válida: {second_option} - {att_option}")
                editing_Student()
                
                #Excluindo um aluno da lista
            elif second_option == 4:
                print(f"Você escolheu a opção válida: {second_option} - {excl_option}")
                student_data = excluding_Student(students)

            elif second_option == 0:
                print("Você pediu para voltar.")  
                break
            else: 
                print(f"Você escolheu uma alternativa incorreta: {second_option}")

    elif option == 0:
            print("Você pediu para sair.")
            break
    elif option == 2 or option == 3 or option == 4 or option == 5: 
            print("Este menu está em desenvolvimento.")

    else:
        print(f"Você escolheu uma alternativa incorreta: {option}")     

